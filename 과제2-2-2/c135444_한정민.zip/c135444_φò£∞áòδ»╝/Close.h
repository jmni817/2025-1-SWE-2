// Close.h
#pragma once
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class SystemController;

class Close {
private:
    SystemController* systemController;
    
public:
    Close(SystemController* systemController);
    void closeRequest();
};