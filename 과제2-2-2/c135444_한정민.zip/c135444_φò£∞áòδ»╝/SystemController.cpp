// SystemController.cpp
#include "SystemController.h"

void SystemController::systemClose() {
    exit(0);    // 시스템 종료
}