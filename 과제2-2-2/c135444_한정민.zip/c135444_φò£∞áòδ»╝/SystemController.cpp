// SystemController.cpp
#include "SystemController.h"

void SystemController::systemClose() {
    exit(0);
}