// SystemController.h
#pragma once
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class SystemController {
public:
    // 시스템 종료 함수
    void systemClose();
};