// SystemController.h
#pragma once
#include <fstream>
#include <string>
#include <vector>
using namespace std;

class SystemController {
public:
    void systemClose();
};